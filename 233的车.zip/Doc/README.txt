  
  PUL1	C6	CCR1        
  PUL2	C7	CCR2
  DIR1	C8	CCR3
  DIR2	C9	CCR4
 

  A9  TX
  A10 RX