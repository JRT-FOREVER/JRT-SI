#include "stm32f10x.h"
#include <stdio.h>

void USART1_Config(void);
void NVIC_Config(void);
int fputc(int ch, FILE *f);
int fgetc(FILE *f);

